This project is fully based on react and react components with routing it can fetch news from news api and can get news from every field
